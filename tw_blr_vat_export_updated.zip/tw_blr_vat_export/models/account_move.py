# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2026 pAq Computer Enterprise (博客電腦企業社)

from odoo import api, fields, models, _
from odoo.exceptions import UserError

class AccountMove(models.Model):
    _inherit = "account.move"

    tw_blr_auto = fields.Boolean(string="BLR欄位自動帶入", default=True)

    # Allow bookkeeping without tax reporting: if enabled, this move will be ignored by the
    # BLR export wizard (both sales & purchases).
    tw_blr_skip_export = fields.Boolean(string="不匯出BLR申報", default=False)

    tw_blr_format_code = fields.Selection(
        selection=[
            ("21","21 進項三聯式、電子計算機統一發票"),
            ("22","22 進項二聯式收銀機統一發票、載有稅額之其他憑證"),
            ("23","23 進貨退出或折讓證明單(三聯式、電子計算機、三聯式收銀機統一發票及一般稅額計算之電子發票)"),
            ("24","24 進貨退出或折讓證明單(二聯式收銀機統一發票及載有稅額之其他憑證)"),
            ("25","25 進項三聯式收銀機統一發票及一般稅額計算之電子發票(含公用事業載具流水號)"),
            ("26","26 彙總登錄：每張稅額500元以下之進項三聯式、電子計算機統一發票"),
            ("27","27 彙總登錄：每張稅額500元以下之進項二聯式收銀機統一發票、載有稅額之其他憑證"),
            ("28","28 進項海關代徵營業稅繳納證"),
            ("29","29 進項海關退還溢繳營業稅申報單"),
            ("31","31 銷項三聯式、電子計算機統一發票"),
            ("32","32 銷項二聯式、二聯式收銀機統一發票"),
            ("33","33 銷貨退回或折讓證明單(三聯式、電子計算機、三聯式收銀機統一發票及一般稅額計算之電子發票)"),
            ("34","34 銷貨退回或折讓證明單(二聯式、二聯式收銀機統一發票及銷項免用統一發票)"),
            ("35","35 銷項三聯式收銀機統一發票及一般稅額計算之電子發票"),
            ("36","36 銷項免用統一發票"),
            ("37","37 銷項憑證、特種稅額計算之電子發票(特種稅額計算)"),
            ("38","38 銷貨退回或折讓證明單(特種稅額計算)")
        ],
        string="BLR格式代號"
    )

    tw_invoice_track = fields.Char(string="發票字軌(2碼)")
    tw_invoice_number = fields.Char(string="發票號碼(8碼)")

    tw_other_voucher_no = fields.Char(string="其他憑證號碼(10碼)")
    tw_utility_carrier_no = fields.Char(string="公用事業載具流水號(BB+8碼)")
    tw_customs_pay_no = fields.Char(string="海關代徵營業稅繳納證號碼(14碼)")

    tw_tax_type = fields.Selection(
        selection=[
            ("1", "1 應稅"),
            ("2", "2 零稅率"),
            ("3", "3 免稅"),
            ("F", "F 作廢發票"),
            ("D", "D 空白未使用"),
        ],
        string="課稅別",
        default="1"
    )

    tw_deduct_code = fields.Selection(
        selection=[
            ("1", "1 可扣抵"),
            ("0", "0 不得扣抵/其他"),
        ],
        string="扣抵代號",
        default="1"
    )

    # -------------------------------------------------------------------------
    # Onchange logic
    # When the tax type changes, adjust the default deduct code to avoid BLR
    # validation errors. If the tax type is zero rate or exempt (2/3), force the
    # deduct code to '0' (non-deductible). Conversely, if tax type is taxable
    # (1) and the deduct code is currently non‑deductible, default to '1'.
    @api.onchange('tw_tax_type')
    def _onchange_tw_tax_type(self):
        for rec in self:
            # Skip if BLR export is disabled
            if rec.tw_blr_skip_export:
                continue
            if rec.tw_tax_type in ('2', '3') and rec.tw_deduct_code == '1':
                rec.tw_deduct_code = '0'
            elif rec.tw_tax_type == '1' and rec.tw_deduct_code == '0':
                # Default to deductable when switching back to taxable
                rec.tw_deduct_code = '1'

    # -------------------------------------------------------------------------
    # BLR validation helper
    def _validate_blr_fields(self):
        """
        Perform BLR field validation for moves before they are posted. This
        reuses the export wizard's internal validation to ensure that the
        identifier and amount checks performed during export also apply at
        posting time. It also enforces certain cross‑field rules such as
        prohibiting deductible codes when the tax type is zero rate or exempt.

        Raises a UserError with a descriptive message if any validation fails.
        """
        # Today's date in ROC calendar for a dummy wizard
        today = fields.Date.context_today(self)
        year_roc = today.year - 1911
        month = today.month
        Wizard = self.env['tw.blr.vat.export.wizard']

        for move in self:
            # Skip validation for moves not exported to BLR
            if move.tw_blr_skip_export:
                continue
            # Only validate invoices/refunds
            if move.move_type not in ('out_invoice', 'out_refund', 'in_invoice', 'in_refund'):
                continue
            # A format code is required for BLR export
            if not move.tw_blr_format_code:
                # Allow missing format code: the wizard will skip these moves,
                # but notify the user at export time instead of blocking posting.
                continue
            # Use a transient wizard to leverage the same validation logic used
            # during export. We create it on the fly and immediately unlink it.
            wizard = Wizard.create({
                'company_id': move.company_id.id,
                'year_roc': year_roc,
                'month': month,
            })
            try:
                # This will run _select_identifier, tax validations and
                # length checks via _txt_line_81. Sequence/period values are
                # arbitrary (we use 1 and the wizard's year/month) since the
                # purpose here is merely to trigger validation. If any check
                # fails, _txt_line_81 will raise an exception.
                wizard._txt_line_81(move, 1, year_roc, month)
            except Exception as e:
                # Normalise exceptions into UserError for a cleaner message
                raise UserError(str(e))
            finally:
                wizard.unlink()

            # Additional rule: zero rate (2) or exempt (3) supplies must not
            # be marked as deductible in BLR. BLR only accepts deductible
            # codes (1/2) for taxable supplies. Even though the UI uses 0/1,
            # the export will map 0→3 and 1→1 or 2. We only need to
            # prohibit the user from selecting deductible when tax type is not
            # taxable.
            tax_type = (move.tw_tax_type or '1')[:1]
            deduct = (move.tw_deduct_code or '1')[:1]
            if tax_type in ('2', '3') and deduct == '1':
                raise UserError(
                    _("課稅別為零稅率/免稅時，扣抵代號不得選擇可扣抵。"))
        return True

    # -------------------------------------------------------------------------
    # Override post to enforce BLR validation
    def action_post(self):
        # Perform BLR validation before posting
        self._validate_blr_fields()
        # Continue with regular posting
        return super().action_post()