# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2026 pAq Computer Enterprise (博客電腦企業社)

import base64
import io
import zipfile
import re
from datetime import date
from odoo import fields, models, _
from odoo.exceptions import UserError


def _digits_only(v):
    if not v:
        return ""
    return "".join(ch for ch in str(v) if ch.isdigit())


def _upper_alnum(v):
    if not v:
        return ""
    return re.sub(r"[^0-9A-Z]", "", str(v).upper())


def _zfill_digits(v, n):
    s = _digits_only(v)
    return (s.zfill(n))[:n]


def _rpad(v, n):
    s = "" if v is None else str(v)
    return (s + (" " * n))[:n]


def _clean(v):
    if v is None:
        return ""
    s = " ".join(str(v).split())
    return s.replace("\r", " ").replace("\n", " ")


class TwBlrVatExportWizard(models.TransientModel):
    _name = "tw.blr.vat.export.wizard"
    _description = "營業稅BLR網路申報匯出"

    company_id = fields.Many2one(
        "res.company",
        required=True,
        default=lambda self: self.env.company,
        string="公司",
    )
    year_roc = fields.Integer(
        string="年度(民國)",
        required=True,
        default=lambda self: date.today().year - 1911,
    )
    month = fields.Integer(
        string="月份(期末月)",
        required=True,
        default=lambda self: date.today().month,
    )
    filing_code = fields.Selection(
        [("1", "1"), ("5", "5")],
        string="申報代號",
        required=True,
        default="1",
    )
    total_pay_code = fields.Selection(
        [("0", "0"), ("1", "1"), ("2", "2")],
        string="總繳代號",
        required=True,
        default="0",
    )
    tax_rate_percent = fields.Float(string="一般稅額徵收率(%)", default=5.0)
    special_tax_rate_percent = fields.Float(string="特種稅額稅率(%)", default=0.0)

    export_zip = fields.Binary(string="匯出ZIP", readonly=True)
    export_zip_name = fields.Char(string="檔名", readonly=True)
    check_report = fields.Text(string="檢核報表", readonly=True)

    def _period_range(self):
        y = int(self.year_roc) + 1911
        m = int(self.month)
        if m < 1 or m > 12:
            raise UserError(_("月份需為1~12"))
        date_from = date(y, m, 1)
        date_to = date(y + 1, 1, 1) if m == 12 else date(y, m + 1, 1)
        return date_from, date_to

    def _get_moves(self, date_from, date_to):
        """
        Enterprise-grade:
        - Domain uses 3-tuple syntax: ('field','op',value)
        - Auto-skip BLR export if account.move has tw_blr_skip_export field and it's True
        """
        domain = [
            ("company_id", "=", self.company_id.id),
            ("state", "=", "posted"),
            ("invoice_date", ">=", date_from),
            ("invoice_date", "<", date_to),
            ("move_type", "in", ("out_invoice", "out_refund", "in_invoice", "in_refund")),
        ]

        # Optional skip flag: only apply if field exists to avoid Domain() crash.
        if "tw_blr_skip_export" in self.env["account.move"]._fields:
            domain.append(("tw_blr_skip_export", "=", False))

        return self.env["account.move"].search(domain)

    def _compute_amounts_for_export(self, move):
        """
        Return (untaxed_amount_int, tax_amount_int) for BLR export.

        Enterprise-grade "B mode":
        If tax_type == '1' (taxable) and deduct_code == '0' (non-deductible/other)
        and Odoo tax is 0 (common when you book with 0% tax for convenience),
        then treat amount_total as tax-included and reverse-calculate untaxed/tax
        using tax_rate_percent so that BLR validation passes.
        """
        tax_type = (move.tw_tax_type or "1")[:1]
        deduct = (move.tw_deduct_code or "1")[:1]

        # Default: trust Odoo's computed values
        amt_untaxed = int(round(move.amount_untaxed))
        tax = int(round(move.amount_tax))

        if tax_type == "1" and deduct == "0" and tax == 0:
            rate = float(self.tax_rate_percent or 0.0) / 100.0
            if rate > 0:
                total = int(round(move.amount_total))
                # Reverse VAT: untaxed = round(total / (1+rate)), tax = total - untaxed
                amt_untaxed = int(round(total / (1.0 + rate)))
                tax = total - amt_untaxed

        return amt_untaxed, tax

    def _select_identifier(self, move, fmt):
        track = _clean(move.tw_invoice_track).upper()
        invno = _zfill_digits(move.tw_invoice_number, 8)
        other = _upper_alnum(move.tw_other_voucher_no)
        util = _upper_alnum(move.tw_utility_carrier_no)
        customs = _upper_alnum(move.tw_customs_pay_no)

        if fmt in ("28", "29"):
            if len(customs) != 14:
                raise UserError(_("格式代號%s需填海關代徵營業稅繳納證/退稅相關號碼(14碼)") % fmt)
            return ("customs", customs)

        if fmt in ("25", "35"):
            if util.startswith("BB") and len(util) == 10:
                return ("utility", util)
            if track and len(track) == 2 and _digits_only(invno) != "00000000":
                return ("inv", track + invno)
            raise UserError(_("格式代號%s需填發票字軌/號碼或公用事業載具流水號(BB+8碼)") % fmt)

        if fmt in ("22", "24", "27", "32", "34", "36"):
            if other and len(other) == 10:
                return ("other", other)
            if track and len(track) == 2 and _digits_only(invno) != "00000000":
                return ("inv", track + invno)
            raise UserError(_("格式代號%s需填發票字軌/號碼或其他憑證號碼(10碼)") % fmt)

        if track and len(track) == 2 and _digits_only(invno) != "00000000":
            return ("inv", track + invno)

        raise UserError(_("格式代號%s需填發票字軌(2碼)+發票號碼(8碼)") % fmt)

    def _txt_line_81(self, move, seq, yyy, mm):
        fmt = move.tw_blr_format_code
        if not fmt or len(fmt) != 2:
            raise UserError(_("單據 %s 缺少BLR格式代號") % (move.display_name,))

        tax_id_9 = _rpad(_digits_only(self.company_id.tw_tax_id_9), 9)
        if len(_digits_only(tax_id_9)) != 9:
            raise UserError(_("公司稅籍編號需為9碼"))

        seq7 = _zfill_digits(seq, 7)
        y3 = _zfill_digits(yyy, 3)
        m2 = _zfill_digits(mm, 2)

        company_vat8 = _zfill_digits((self.company_id.vat or "").replace("TW", ""), 8)
        partner_vat8 = _zfill_digits((move.partner_id.vat or "").replace("TW", ""), 8)

        if len(_digits_only(company_vat8)) != 8:
            raise UserError(_("公司統一編號需為8碼"))

        if move.move_type in ("out_invoice", "out_refund"):
            buyer8 = partner_vat8 if partner_vat8.strip() else " " * 8
            seller8 = company_vat8
        else:
            buyer8 = company_vat8
            seller8 = partner_vat8 if partner_vat8.strip() else " " * 8

        kind, ident = self._select_identifier(move, fmt)

        track2 = "  "
        inv8 = "00000000"
        if kind == "inv":
            track2 = ident[:2]
            inv8 = ident[2:]
        elif kind == "other":
            track2 = "OT"
            inv8 = ident[:8]
        elif kind == "utility":
            track2 = "BB"
            inv8 = ident[2:]
        elif kind == "customs":
            track2 = "CU"
            inv8 = ident[:8]

        amt, tax = self._compute_amounts_for_export(move)
        tax_type = (move.tw_tax_type or "1")[:1]
        deduct = (move.tw_deduct_code or "1")[:1]

        # Validation
        if fmt not in ("37", "38"):
            if tax_type in ("2", "3") and tax != 0:
                raise UserError(_("單據 %s 課稅別為零稅率/免稅時，稅額需為0") % (move.display_name,))
            if tax_type == "1":
                expected = int(round(amt * (self.tax_rate_percent / 100.0)))
                if abs(expected - tax) > 1:
                    raise UserError(
                        _("單據 %s 稅額檢核失敗：未稅=%s 推算稅額≈%s 實際稅額=%s")
                        % (move.display_name, amt, expected, tax)
                    )

        s = ""
        s += _rpad(fmt, 2)
        s += _rpad(tax_id_9, 9)
        s += _rpad(seq7, 7)
        s += y3
        s += m2
        s += _rpad(buyer8, 8)
        s += _rpad(seller8, 8)
        s += _rpad(track2, 2)
        s += _rpad(inv8, 8)
        s += _rpad(_zfill_digits(amt, 12), 12)
        s += _rpad(tax_type, 1)
        s += _rpad(_zfill_digits(tax, 10), 10)
        s += _rpad(deduct, 1)
        s += " " * 8

        if len(s) != 81:
            raise UserError(_("TXT單行必須81字元，實際=%s") % len(s))
        return s

    def _tet_u_line(self, totals):
        f = ["0"] * 112
        f[0] = "1"
        f[1] = "00000001"
        f[2] = _zfill_digits((self.company_id.vat or "").replace("TW", ""), 8)
        f[3] = _zfill_digits(self.year_roc, 3) + _zfill_digits(self.month, 2)
        f[4] = self.filing_code
        f[5] = _rpad(_digits_only(self.company_id.tw_tax_id_9), 9)
        f[6] = self.total_pay_code
        f[7] = _zfill_digits(totals.get("invoice_count", 0), 10)
        f[8] = _zfill_digits(totals.get("taxable_sales", 0), 12)
        f[24] = _zfill_digits(totals.get("output_tax", 0), 10)
        f[72] = _zfill_digits(totals.get("input_tax_deductible", 0), 10)
        f = [_clean(x) for x in f]
        return "|".join(f)

    def action_generate_zip(self):
        company = self.company_id

        if not company.vat:
            raise UserError(_("請先在公司資料填寫統一編號(8碼)"))
        if not company.tw_tax_id_9 or len(_digits_only(company.tw_tax_id_9)) != 9:
            raise UserError(_("請先在公司資料填寫稅籍編號(9碼)"))

        date_from, date_to = self._period_range()
        moves = self._get_moves(date_from, date_to)

        yyy = int(self.year_roc)
        mm = int(self.month)

        errors = []
        exported = []
        seq = 1
        txt_lines = []
        invoice_count = 0
        taxable_sales = 0
        output_tax = 0
        input_tax_deductible = 0

        for mv in moves.sorted(lambda m: (m.invoice_date or m.date, m.name)):
            # Auto-fill format code if enabled
            if mv.tw_blr_auto and (not mv.tw_blr_format_code):
                if mv.move_type in ("in_invoice", "in_refund"):
                    mv.tw_blr_format_code = "25" if (mv.tw_utility_carrier_no or "").upper().startswith("BB") else "21"
                else:
                    mv.tw_blr_format_code = "35" if (mv.tw_invoice_track and mv.tw_invoice_number) else "31"

            if not mv.tw_blr_format_code:
                exported.append((mv.display_name, "跳過：缺BLR格式代號"))
                continue

            try:
                line = self._txt_line_81(mv, seq, yyy, mm)
                txt_lines.append(line)
                seq += 1
                invoice_count += 1

                amt, tax = self._compute_amounts_for_export(mv)
                tax_type = (mv.tw_tax_type or "1")[:1]
                deduct = (mv.tw_deduct_code or "1")[:1]

                if mv.move_type in ("out_invoice", "out_refund"):
                    if tax_type == "1":
                        taxable_sales += amt
                        output_tax += tax
                else:
                    if deduct == "1":
                        input_tax_deductible += tax

                exported.append((mv.display_name, "OK"))
            except Exception as e:
                errors.append(f"{mv.display_name}: {e}")

        if errors:
            raise UserError(_("匯出失敗，請先修正：\n- %s") % ("\n- ".join(errors)))

        vat8 = _zfill_digits((company.vat or "").replace("TW", ""), 8)
        txt_name = f"{vat8}.TXT"
        tet_name = f"{vat8}.TET_U"

        totals = {
            "invoice_count": invoice_count,
            "taxable_sales": taxable_sales,
            "output_tax": output_tax,
            "input_tax_deductible": input_tax_deductible,
        }

        txt_content = ("\r\n".join(txt_lines) + ("\r\n" if txt_lines else "")).encode("utf-8")
        tet_content = (self._tet_u_line(totals) + "\r\n").encode("utf-8")

        rep = []
        rep.append("營業稅(BLR)匯出檢核報表")
        rep.append(f"統一編號：{vat8}")
        rep.append(f"稅籍編號(9碼)：{_digits_only(company.tw_tax_id_9)}")
        rep.append(f"申報期別(民國)：{_zfill_digits(self.year_roc,3)}{_zfill_digits(self.month,2)}")
        rep.append("")
        rep.append(f"明細行數(BAN.TXT)：{invoice_count}")
        rep.append(f"應稅銷售額(未稅)：{taxable_sales}")
        rep.append(f"銷項稅額：{output_tax}")
        rep.append(f"進項可扣抵稅額：{input_tax_deductible}")
        rep.append("")
        rep.append("逐筆結果：")
        for name, st in exported:
            rep.append(f"- {name}：{st}")
        if not moves:
            rep.append("- 本期無已過帳單據")
        rep_text = "\r\n".join(rep) + "\r\n"
        self.check_report = rep_text

        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(txt_name, txt_content)
            zf.writestr(tet_name, tet_content)
            zf.writestr("CHECK_REPORT.txt", rep_text.encode("utf-8"))

        self.export_zip = base64.b64encode(buf.getvalue())
        self.export_zip_name = f"{vat8}_BLR_VAT_{_zfill_digits(self.year_roc,3)}{_zfill_digits(self.month,2)}.zip"

        return {
            "type": "ir.actions.act_window",
            "res_model": "tw.blr.vat.export.wizard",
            "view_mode": "form",
            "res_id": self.id,
            "target": "new",
        }