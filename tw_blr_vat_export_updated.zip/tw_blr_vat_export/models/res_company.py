# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2026 pAq Computer Enterprise (博客電腦企業社)

from odoo import fields, models

class ResCompany(models.Model):
    _inherit = "res.company"

    tw_tax_id_9 = fields.Char(string="稅籍編號(9碼)")
    tw_filer_idno = fields.Char(string="申報人身分證統一編號(10碼)")
    tw_filer_name = fields.Char(string="申報人姓名")
    tw_filer_tel_area = fields.Char(string="申報人電話區碼")
    tw_filer_tel = fields.Char(string="申報人電話")
    tw_filer_tel_ext = fields.Char(string="申報人電話分機")
    tw_agent_reg_no = fields.Char(string="代理申報人登錄(文)字號")
