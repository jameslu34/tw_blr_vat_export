# 貢獻指南

感謝你願意貢獻！此 repo 以「可直接放進 Odoo addons_path 就能用」為目標。

## 開發環境建議

- Python 3.10+（依你的 Odoo 19 環境而定）
- 建議使用 `pre-commit` 進行格式與靜態檢查

## 提交流程

1. Fork + 建立分支
2. 本機先跑：
   - `pre-commit run -a`
3. PR 說明請包含：
   - 修改原因
   - 影響範圍（是否涉及匯出格式）
   - 若有行為變更，請附上測試方式與截圖（如果適用）

## 版本規則

- `__manifest__.py` 的 `version` 採語意化版本（SemVer）
- 破壞性變更請提高 major



# Contributing

Thanks for your interest in contributing! This repository aims to be “drop-in ready” for Odoo by simply placing it under the Odoo `addons_path`.

## Recommended Development Environment

- Python 3.10+ (depending on your Odoo 19 environment)
- We recommend using `pre-commit` for formatting and static checks

## Contribution Workflow

1. Fork the repository and create a new branch
2. Run locally before opening a PR:
   - `pre-commit run -a`
3. Your PR description should include:
   - Why the change is needed
   - Scope of impact (especially whether it affects the export format)
   - If behavior changes, provide test steps and screenshots (if applicable)

## Versioning Rules

- Use Semantic Versioning (SemVer) for `version` in `__manifest__.py`
- Increase the major version for breaking changes