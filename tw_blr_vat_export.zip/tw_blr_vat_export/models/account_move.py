# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2026 pAq Computer Enterprise (博客電腦企業社)

from odoo import fields, models

class AccountMove(models.Model):
    _inherit = "account.move"

    tw_blr_auto = fields.Boolean(string="BLR欄位自動帶入", default=True)

    # Allow bookkeeping without tax reporting: if enabled, this move will be ignored by the
    # BLR export wizard (both sales & purchases).
    tw_blr_skip_export = fields.Boolean(string="不匯出BLR申報", default=False)

    tw_blr_format_code = fields.Selection(
        selection=[
            ("21","21 進項三聯式、電子計算機統一發票"),
            ("22","22 進項二聯式收銀機統一發票、載有稅額之其他憑證"),
            ("23","23 進貨退出或折讓證明單(三聯式、電子計算機、三聯式收銀機統一發票及一般稅額計算之電子發票)"),
            ("24","24 進貨退出或折讓證明單(二聯式收銀機統一發票及載有稅額之其他憑證)"),
            ("25","25 進項三聯式收銀機統一發票及一般稅額計算之電子發票(含公用事業載具流水號)"),
            ("26","26 彙總登錄：每張稅額500元以下之進項三聯式、電子計算機統一發票"),
            ("27","27 彙總登錄：每張稅額500元以下之進項二聯式收銀機統一發票、載有稅額之其他憑證"),
            ("28","28 進項海關代徵營業稅繳納證"),
            ("29","29 進項海關退還溢繳營業稅申報單"),
            ("31","31 銷項三聯式、電子計算機統一發票"),
            ("32","32 銷項二聯式、二聯式收銀機統一發票"),
            ("33","33 銷貨退回或折讓證明單(三聯式、電子計算機、三聯式收銀機統一發票及一般稅額計算之電子發票)"),
            ("34","34 銷貨退回或折讓證明單(二聯式、二聯式收銀機統一發票及銷項免用統一發票)"),
            ("35","35 銷項三聯式收銀機統一發票及一般稅額計算之電子發票"),
            ("36","36 銷項免用統一發票"),
            ("37","37 銷項憑證、特種稅額計算之電子發票(特種稅額計算)"),
            ("38","38 銷貨退回或折讓證明單(特種稅額計算)")
        ],
        string="BLR格式代號"
    )

    tw_invoice_track = fields.Char(string="發票字軌(2碼)")
    tw_invoice_number = fields.Char(string="發票號碼(8碼)")

    tw_other_voucher_no = fields.Char(string="其他憑證號碼(10碼)")
    tw_utility_carrier_no = fields.Char(string="公用事業載具流水號(BB+8碼)")
    tw_customs_pay_no = fields.Char(string="海關代徵營業稅繳納證號碼(14碼)")

    tw_tax_type = fields.Selection(
        selection=[
            ("1", "1 應稅"),
            ("2", "2 零稅率"),
            ("3", "3 免稅"),
            ("F", "F 作廢發票"),
            ("D", "D 空白未使用"),
        ],
        string="課稅別",
        default="1"
    )

    tw_deduct_code = fields.Selection(
        selection=[
            ("1", "1 可扣抵"),
            ("0", "0 不得扣抵/其他"),
        ],
        string="扣抵代號",
        default="1"
    )