# 臺灣營業稅BLR網路申報匯出模組（Odoo 19）

> \*\*臺灣營業稅BLR網路申報匯出模組\*\*：從 Odoo 的會計資料產生「營業稅(BLR)媒體申報匯入檔」（TXT / `TET\_U`），提供下載（含壓縮打包）。

## 功能摘要

* 公司層級欄位：設定營業人資料（如統編、申報相關欄位）
* 發票/分錄層級欄位：補充 BLR 匯出所需資訊
* 匯出精靈：依申報期間產出 TXT（`TET\_U`）並可打包下載

> 模組定位：讓你可以把 Odoo 19 Community 的會計資料，整理成臺灣營業稅 BLR 上傳所需的匯入檔。

## 支援版本

* Odoo **19.0** Community / Enterprise（依賴 `account`）

## 安裝方式

1. 將本 repo 下載後，把 `tw\_blr\_vat\_export/` 放到你的 Odoo `addons\_path` 之一
2. 重新啟動 Odoo
3. 到 **Apps** 搜尋 `營業稅(BLR)網路申報匯出` 並安裝

## 使用方式（概略）

1. 進入 **設定 → 公司**（或會計相關設定頁）完成 BLR 匯出必要欄位
2. 於會計憑證/發票上確認相關欄位資料完整
3. 進入匯出精靈，選擇期間後匯出 `TET\_U`（或含 ZIP）

## 開發 / 品質工具

本 repo 內建 **pre-commit** 與 OCA 系列的檢查器（包含 `pylint-odoo` 與 `odoo-pre-commit-hooks`）。

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip pre-commit
pre-commit install
pre-commit run -a
```

## 授權

* 本專案採 **LGPL-3.0-or-later**（見 `LICENSE`）

## 參與貢獻

請先閱讀 `CONTRIBUTING.md`。



# Taiwan VAT BLR Online Filing Export Module (Odoo 19)

> **Taiwan VAT BLR Online Filing Export Module**: Generate the “VAT (BLR) media filing import file” (TXT / `TET_U`) from Odoo accounting data, and provide it for download (optionally bundled as ZIP).

## Features

- Company-level fields: Configure business information (e.g., VAT ID / tax registration number, filing-related fields)
- Invoice/Journal Entry-level fields: Fill in additional data required for BLR export
- Export wizard: Generate TXT (`TET_U`) for a selected filing period and optionally bundle it as ZIP

> Module positioning: Convert Odoo 19 Community accounting data into a BLR-importable file for Taiwan VAT online filing.

## Supported Versions

- Odoo **19.0** Community / Enterprise (depends on `account`)

## Installation

1. Download this repo and place `tw_blr_vat_export/` into one of your Odoo `addons_path` directories
2. Restart Odoo
3. Go to **Apps**, search for “VAT (BLR) Online Filing Export” (or your module display name), then install

## Usage (High-level)

1. Go to **Settings → Companies** (or accounting-related settings) and complete the required BLR export fields
2. Ensure the related fields on invoices/journal entries are complete
3. Open the export wizard, select the period, and export `TET_U` (optionally with ZIP)

## Development / Quality Tools

This repo includes **pre-commit** and OCA tooling (including `pylint-odoo` and `odoo-pre-commit-hooks`).

```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip pre-commit
pre-commit install
pre-commit run -a
