# 安全性政策

若你發現安全性問題（例如：未授權存取、資料外洩、RCE 等），請**不要**直接開 public issue。

建議使用 GitHub 的 **Private Vulnerability Reporting / Security Advisory** 功能（repo 的 Security 分頁）私下回報。

若你無法使用該功能，也可以改用你平常與維護者聯絡的管道私下回報。



# Security Policy

If you discover a security issue (e.g., unauthorized access, data leakage, RCE, etc.), please **do not** open a public issue.

## Reporting

### Preferred: GitHub Private Vulnerability Reporting / Security Advisory

If this repository has GitHub Private Vulnerability Reporting enabled, please use the repository **Security** tab and click **Report a vulnerability** to submit a private report to the maintainers.

### Alternative: Contact the maintainer privately

If you cannot use the feature above, please report the issue through your usual private channel used to contact the maintainer.

## Confidentiality

Please keep vulnerability details confidential until we have had a chance to confirm and address the issue.