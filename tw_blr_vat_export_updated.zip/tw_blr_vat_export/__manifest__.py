# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2026 pAq Computer Enterprise (博客電腦企業社)

{
    "name": "臺灣營業稅BLR網路申報匯出模組",
    # Increase the version number to reflect updated BLR validations and UI logic.
    "version": "1.2.1",
    "category": "Accounting/Localizations",
    "summary": "輸出營業稅BLR網路申報匯入檔",
    "license": "LGPL-3",
    "author": "pAq Computer Enterprise",
    "depends": ["account"],
    "data": [
        "security/ir.model.access.csv",
        "views/res_company_views.xml",
        "views/account_move_views.xml",
        "wizard/blr_vat_export_wizard_views.xml"
    ],
    "installable": True,
    "application": False
}
